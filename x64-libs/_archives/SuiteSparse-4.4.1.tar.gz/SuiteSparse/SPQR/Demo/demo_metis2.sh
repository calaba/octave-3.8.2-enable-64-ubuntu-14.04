./qrdemo_gpu2 A.mtx 6 > o_metis_withgpu
