invalid symmetric matrix (entries in upper part of A)
             3             1             1             1
isa                        4             4            16             0
(26I3)          (40I2)          (26I3)              
  1  5  9 13 17
 1 2 3 4 1 2 3 4 1 2 3 4 1 2 3 4
 16  5  9  4  2 11  7 14  3 10  6 15 13  8 12  1
